# LOOP Movement Library — Production Handoff

Design-phase deliverable, ready for integration into LOOP (`index.html`).
Production repo untouched; this bundle is the integration source.

## Bundle
- `loop-movement.js` — the complete system: engine + 34-movement registry. Zero dependencies, pure inline SVG, no video/GIF/raster, ~55 KB unminified.

## Integration (drop-in)
1. Include the script once: `<script src="loop-movement.js"></script>` (or paste the IIFE into LOOP's bundle).
2. Render a movement anywhere:
   `<loop-move movement="hip_flexor_stretch" style="width:100%;height:300px"></loop-move>`
3. Attributes (all reactive):
   - `movement` — registry id (see below)
   - `highlight` — `on` (default) | `off` — target-area glow
   - `tempo` — playback multiplier, e.g. `0.8`
   - `animate` — `off` forces the static reduced-motion pose
4. Data access: `window.LoopMovement.get(id)` → full record (`name, tag, area, cat, pattern, equip, role, duration|reps, instruction, cue2, purpose`); `window.LoopMovement.MOVEMENTS`, `.CATEGORIES`.

## Behavior guarantees
- `prefers-reduced-motion: reduce` → clearest static pose per movement (the authored `rest` frame), highlight preserved, no animation; live media-query listener included.
- Scales without distortion (viewBox + `preserveAspectRatio`); verified 375×812, 390×844, and landscape.
- One `requestAnimationFrame` loop per mounted figure; unmount cancels it.
- Accessible: each SVG carries `role="img"` + aria-label (name + instruction).

## Registry (34)
Ids reuse LOOP's production `PREP_MOVEMENTS` / `COOLDOWN_STRETCHES` where the movement exists; new ids follow the same conventions.
- Dynamic mobility (13): world_greatest, arm_circles, band_passthrough, reach_rotate, leg_swing_front, leg_swing_side, hip_9090, thoracic_rotation, standing_cat_cow, wall_slide, ankle_rock, hamstring_sweep, deep_squat_hold
- Activation (6): band_pull_apart, face_pull_light, scap_pushup, glute_bridge, bird_dog, calf_raise
- Movement prep (4): push_up_slow, bodyweight_squat, reverse_lunge, hip_hinge
- Stretch / cooldown (11): hip_flexor_stretch, hamstring_stretch, quad_stretch (role: both), calf_stretch, standing_figure4, shoulder_cross_body, triceps_overhead, chest_opener, lat_stretch, dead_hang, child_pose

Removed v1 → v2 (standing replacements): open_book→reach_rotate, thread_needle→band_passthrough, cat_cow→standing_cat_cow, march_in_place→quad_stretch (promoted), dead_bug→hip_hinge, glute_figure4→standing_figure4, chest_doorway→chest_opener.

## Pre-handoff QA (frame-pinned inspection at start/mid/end/loop + reduced pose)
90/90 Hip Switch — PASS (feet planted through the knees-up transition; hands planted; both sides distinct)
Reverse Lunge — PASS · Band Pull-Apart — PASS · Arm Circles — PASS (elliptical orbit; hands cross only slightly at midline) · Wall Slide — PASS · Bird Dog — PASS (contralateral) · Deep Lunge — PASS
No movements below the quality gate. Standing note: 90/90 remains the one movement a fixed 2-D camera compresses most — reviewed and passing, still worth a glance on device.

## Notes for the integrating engineer
- Each movement's `cue2` is an internal advanced cue — not currently surfaced in the runner; reserved for progressive coaching.
- `duration` is seconds for holds; `reps` present where rep-based. The runner shows 3–5 movements per sequence; the library exists for rotation, never expose all 34 in the user flow.
- Demonstrations are visual guidance only — no medical/injury claims anywhere in the copy; keep it that way.
